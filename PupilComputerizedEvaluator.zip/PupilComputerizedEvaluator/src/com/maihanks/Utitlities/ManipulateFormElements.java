/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.maihanks.Utitlities;

/**
 *
 * @author MAIHANKS
 */
public class ManipulateFormElements {
    //returns the content(value) of a password field named 'passwordTextField'

    public static String getContentOfPasswordField(javax.swing.JPasswordField jpassword) {
        String passwordValue = "";
        for (char character : jpassword.getPassword()) {
            passwordValue = passwordValue + character;
        }
        return passwordValue;
    }//end getContentOfPasswordField()

    //returns true if the parameter value is numeric
    public static boolean isValueNumeric(String value) {
        boolean status = false;
        try {
            Double.parseDouble(value);
            status = true;//value is a numeral
        } catch (Exception e) {//value is not a numeral
        }//end catch
        return status;
    }//end isValueNumeric()
}
