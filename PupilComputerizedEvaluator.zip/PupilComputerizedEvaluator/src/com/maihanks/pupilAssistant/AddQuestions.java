/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.maihanks.pupilAssistant;

import com.maihanks.FileDatabaseManager.Database;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

/**
 *
 * @author ABEL
 */
public class AddQuestions extends JFrame {

    /**
     * This class enables the adding of questions to the database
     */
    private String dbUrl = "src\\com\\maihanks\\Resources\\Database";//url common to all databases
    private String englishDatabase[] = {dbUrl + "\\EnglishQuestionsEasy.txt", dbUrl + "\\EnglishQuestionsDifficult.txt", dbUrl + "\\EnglishQuestionsVeryDifficult.txt", dbUrl + "\\EnglishQuestionsExpert.txt"};
    private Database databaseWriter[] = new Database[4]; //to be used for writting records to respective databases
    private JPanel parentPanel = new JPanel();//to wrap main frame
    private JTextArea qstTextArea = new javax.swing.JTextArea(15, 10);//to collect question
    private JTextField optionsTextField[] = new JTextField[4];
    private JLabel optionsDescLabel[] = {new JLabel("Option A (Answer)"), new JLabel("Option B"), new JLabel("Option C"), new JLabel("Option D")};
    private JLabel difficultyLevelLabel = new JLabel("Difficulty Level");
    private String difficultyLevel[] = {"", "Easy", "Difficilt", "Very Difficult", "Expert"};
    private JComboBox difficultyLevelComboBox = new javax.swing.JComboBox(difficultyLevel);
    private JButton submitButton = new JButton("submit");
    private JPanel leftParentPanel = new JPanel(), rightParentPanel = new JPanel();
    private Color defaultColor = new Color(230, 100, 50);
    private String record = "";//record to be sent to database

    public AddQuestions() {
        super("Add Questions");
        setUpDatabaseAccess();
        setUpParentPanel();
        registerEventHandlers();
    }

    /**
     * This method enables access to database
     */
    private void setUpDatabaseAccess() {
        for (int a = 0; a < databaseWriter.length; a++) {//populates databaseWriter[]
            databaseWriter[a] = new Database(englishDatabase[a]);
        }//end for  
    }//end setUpDatabaseAccess()

    /**
     * This method sets up the ParentPanel's display
     */
    private void setUpParentPanel() {
        for (int a = 0; a < optionsTextField.length; a++) {
            optionsTextField[a] = new JTextField();//initializes textfields
        }//end for
        parentPanel.setSize(this.getWidth(), this.getHeight());//sets dimensions
        parentPanel.setLayout(new GridLayout(1, 2));//absolute layout
        this.leftParentPanel.setBackground(defaultColor);
        //leftParentPanel.setBounds(0,0,parentPanel.getWidth()/2,parentPanel.getHeight());
        this.rightParentPanel.setBackground(defaultColor);
        // rightParentPanel.setBounds(parentPanel.getWidth()/2,0,parentPanel.getWidth()/2,parentPanel.getHeight());
        leftParentPanel.setLayout(null);
        // qstTextArea.setBounds(0, 40, 200, 220);
        JScrollPane scroll = new javax.swing.JScrollPane(qstTextArea);
        scroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
        scroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        scroll.setBounds(0, 40, 200, 220);
        leftParentPanel.add(scroll);
        
        difficultyLevelLabel.setBounds(150, 300, 120, 20);
        leftParentPanel.add(difficultyLevelLabel);
        
        difficultyLevelComboBox.setBounds(150, 350, 100, 20);
        leftParentPanel.add(difficultyLevelComboBox);
        
        submitButton.setBounds(220, 400, 100, 20);
        leftParentPanel.add(submitButton);
        
        
        rightParentPanel.setLayout(null);
        optionsDescLabel[0].setBounds(0, 100, 100, 20);
        optionsDescLabel[1].setBounds(0, 120, 100, 20);
        optionsDescLabel[2].setBounds(0, 140, 100, 20);
        optionsDescLabel[3].setBounds(0, 160, 100, 20);
        
        optionsTextField[0].setBounds(125, 100, 100, 20);
        optionsTextField[1].setBounds(125, 120, 100, 20);
        optionsTextField[2].setBounds(125, 140, 100, 20);
        optionsTextField[3].setBounds(125, 160, 100, 20);
        
        for (int a = 0; a < optionsDescLabel.length; a++) {
            rightParentPanel.add(optionsDescLabel[a]);
            rightParentPanel.add(optionsTextField[a]);
        }
        parentPanel.setBackground(defaultColor);
        parentPanel.add(leftParentPanel);
        parentPanel.add(rightParentPanel);
        super.add(parentPanel);
    }//end setUpParentPanel()

    /**
     * This method begins the execution of this module
     */
    public void start() {
        super.setDefaultCloseOperation(AddQuestions.EXIT_ON_CLOSE);
        super.setBounds(200, 100, 700, 600);
        super.setVisible(true);
    }

    /**
     * registers event handlers
     */
    private void registerEventHandlers() {
        
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (isAnyFieldEmpty() == false) {
                    record = qstTextArea.getText() + databaseWriter[0].getDelimeter() + optionsTextField[0].getText() + databaseWriter[0].getDelimeter()
                            + optionsTextField[1].getText() + databaseWriter[0].getDelimeter() + optionsTextField[2].getText() + databaseWriter[0].getDelimeter()
                            + optionsTextField[3].getText();
                    for (int a = 1; a < difficultyLevel.length; a++) {//searches for the appropriate database to send record to
                        if (difficultyLevelComboBox.getSelectedItem().toString().equals(difficultyLevel[a])) {
                            databaseWriter[a - 1].write(record); //sends record to database
                            JOptionPane.showMessageDialog(null, "Records sent successfully");
                            break;//exit loop
                        } else {
                            //JOptionPane.showMessageDialog(null, "Unable to send records");
                        }
                    }//end for loop

                } else {
                    JOptionPane.showMessageDialog(null, "Please Fill all the fields before submiting");
                }
            }
        });
        
    }//end registerEventHandlers()

    private boolean isOptionsTextFieldEmpty() {
        boolean status = false;
        for (int a = 0; a < optionsTextField.length; a++) {
            if (!optionsTextField[a].getText().equals("") && !optionsTextField[a].getText().equals(null)) {
                status = false;
            }//end if
            else {
                status = true;
                break;
            }
        }//end for  
        return status;
    }
    
    private boolean isAnyFieldEmpty() {
        boolean status = true;
        if ((!qstTextArea.getText().equals(null) && !qstTextArea.getText().equals("")) && (!difficultyLevelComboBox.getSelectedItem().toString().equals(""))
                && (isOptionsTextFieldEmpty() == false)) {
            status = false;
        }
        return status;
    }
    
    public static void main(String[] args) {
        AddQuestions addQuestions = new AddQuestions();
        addQuestions.start();
    }//end main
}
