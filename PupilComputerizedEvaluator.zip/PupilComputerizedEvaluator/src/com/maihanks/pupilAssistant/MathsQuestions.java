/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.maihanks.pupilAssistant;

import java.util.Random;

/**
 *
 * @author MAIHANKS
 */
public class MathsQuestions implements Question {

    private int num1, num2;
    private int correctAnswer = 0;
    private String correctAnswerString;

    public MathsQuestions() {
    }

    /**
     * returns the first number generated
     *
     * @return
     */
    public int getNum1() {
        return num1;
    }//end getNum1()

    /**
     * returns the second number generated
     *
     * @return
     */
    public int getNum2() {
        return num2;
    }//end getNum2()

    @Override
    public String generateQuestion(DIFFICULTY_LEVEL difficultyLevel) {
        getNumWrtDifficultyLevel(difficultyLevel);
        String generatedQuestion = "";
        Random randomQuestionType = new Random();
        int type = 1 + randomQuestionType.nextInt(4);

        String operator = "";
        if (type == 1) {
            operator = "+";
            correctAnswer = num1 + num2;
            correctAnswerString = correctAnswer + "";
        } else if (type == 2) {
            operator = "-";
            correctAnswer = num1 - num2;
            correctAnswerString = correctAnswer + "";
        }
        if (type == 3) {
            operator = "*";
            correctAnswer = num1 * num2;
            correctAnswerString = correctAnswer + "";
        }
        if (type == 4) {
            operator = "/";
            double answerDouble;
            answerDouble = Double.parseDouble(num1+"") / Double.parseDouble(num2+"");
            String standardAnswer;

            String ansString, integerPartString, decimalPartString;
            int decimalPart;

            ansString = answerDouble + "";
            integerPartString = ansString.substring(0, ansString.indexOf('.'));
            decimalPartString = ansString.substring(ansString.indexOf('.') + 1);
            decimalPart = Integer.parseInt(decimalPartString);
            if (decimalPart == 0) {
                standardAnswer = integerPartString;
            } else if (decimalPartString.length() <= 4) {
                standardAnswer = ansString;
            } else {//value exceeds 4dcm

                if (Integer.parseInt(decimalPartString.charAt(4) + "") > 4) {
                    int a = 0;
                    a = Integer.parseInt(decimalPartString.charAt(3) + "") + 1;
                    System.out.println(" a = " + a);
                    standardAnswer = integerPartString + "." + decimalPartString.substring(0, 3) + a;
                } else {
                    standardAnswer = integerPartString + "." + decimalPartString;
                }
            }

            correctAnswerString = standardAnswer;
        }
        generatedQuestion = getNum1() + "    " + operator + "    " + getNum2() + "   =    ";
        // JOptionPane.showMessageDialog(null,"Correct answer from MathsQuestions = "+correctAnswer);
        return generatedQuestion;
    }

    private void getNumWrtDifficultyLevel(DIFFICULTY_LEVEL difficultyLevel) {
        Random randomNumbers = new Random();
        if (difficultyLevel == DIFFICULTY_LEVEL.EASY) { //generates one digit numbers
            num1 = 1 + randomNumbers.nextInt(9);//generates one digit number
            num2 = 1 + randomNumbers.nextInt(9);//generates one digit number
        } else if (difficultyLevel == DIFFICULTY_LEVEL.DIFFICULT)//generates two digit numbers
        {
            num1 = 10 + randomNumbers.nextInt(99);//generates two digit number
            num2 = 10 + randomNumbers.nextInt(99);//generates two digit number
        } else if (difficultyLevel == DIFFICULTY_LEVEL.VERY_DIFFICULT)//generates three digit numbers
        {
            num1 = 100 + randomNumbers.nextInt(999);//generates three digit number
            num2 = 100 + randomNumbers.nextInt(999);//generates three digit number
        } else if (difficultyLevel == DIFFICULTY_LEVEL.EXPERT)//generates four digit numbers
        {
            num1 = 1000 + randomNumbers.nextInt(9999);//generates four digit number
            num2 = 1000 + randomNumbers.nextInt(9999);//generates four digit number
        }

    }

    @Override
    public int getNumOfPasses() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public int getNumOfFailures() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public boolean isPromoted(int passes, int failures) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public String getSubject() {
        return ("maths");
    }

    @Override
    public String getComment(boolean passed) {
        Random randomComments = new Random();
        String comment = null;
        int pass = 1 + randomComments.nextInt(4);
        if (passed == true) {//an instant where a pupil supplies one correct answer
            switch (pass) {
                case 1:
                    comment = "Very good!";
                    break;
                case 2:
                    comment = "Excellent!";
                    break;
                case 3:
                    comment = "Nice Work!";
                    break;
                case 4:
                    comment = "Keep up the good work!";
                    break;
            }//end switch
        }//end if
        else {//an instant where a pupil supplies one wrong answer
            switch (pass) {
                case 1:
                    comment = "No. Please Try again.";
                    break;
                case 2:
                    comment = "Wrong. Try once more";
                    break;
                case 3:
                    comment = "Don't give up!";
                    break;
                case 4:
                    comment = "No. keep trying";
                    break;
            }//end switch 
        }//end else
        return comment;
    }

    @Override
    public String getCorrectAnswer() {
        return correctAnswerString;
    }

    public static void main(String[] args) {
        // MathsQuestions mathsQuestions = new MathsQuestions();
        // System.out.println(mathsQuestions.generateQuestion(DIFFICULTY_LEVEL.EASY));
        /*System.out.println(" num1 = " + mathsQuestions.getNum1());
         System.out.println(" num2 = " + mathsQuestions.getNum2());
         System.out.println("Correct answer = " + mathsQuestions.getCorrectAnswer());
         */
double answerDouble = 5 / 7;
            String standardAnswer;

            String ansString, integerPartString, decimalPartString;
            int decimalPart;

            ansString = answerDouble + "";
            integerPartString = ansString.substring(0, ansString.indexOf('.'));
            decimalPartString = ansString.substring(ansString.indexOf('.') + 1);
            decimalPart = Integer.parseInt(decimalPartString);
            if (decimalPart == 0) {
                standardAnswer = integerPartString;
            } else if (decimalPartString.length() <= 4) {
                standardAnswer = ansString;
            } else {//value exceeds 4dcm

                if (Integer.parseInt(decimalPartString.charAt(4) + "") > 4) {
                    int a = 0;
                    a = Integer.parseInt(decimalPartString.charAt(3) + "") + 1;
                    System.out.println(" a = " + a);
                    standardAnswer = integerPartString + "." + decimalPartString.substring(0, 3) + a;
                } else {
                    standardAnswer = integerPartString + "." + decimalPartString;
                }
            }
       // System.out.println("ans = "+answerDouble);
       // System.out.println("standard answer = "+standardAnswer);

        
    }//end main

    @Override
    public String[] getOptions() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
