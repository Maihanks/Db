/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.maihanks.pupilAssistant;

import com.maihanks.FileDatabaseManager.Database;
import com.maihanks.Utitlities.ManipulateFormElements;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

/**
 *
 * 
 */
public class RegisterClient extends JFrame {

    private JPanel parentPanel = new JPanel();
    private JLabel descriptionLabel[] = {new JLabel("First Name"), new JLabel("Last Name"), new JLabel("Password"), new JLabel()};
    private JTextField textField[] = {new JTextField(), new JTextField()};
    private JPasswordField password = new JPasswordField();
    private JButton sumbitButton = new JButton("Register"), adminHomeButton = new JButton("Home");
    private String databaseUrl = "";
    private Database databaseAccess;

    public RegisterClient(String theDatabaseUrl) {
        super("Register");
        databaseAccess = new Database(theDatabaseUrl);
        super.setBounds(500, 200, 400, 400);
        super.setLayout(null);
        super.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    /**
     * sends record to database
     * @param record 
     */
    private void registerClient(String record) {
        databaseAccess.write(record);
    }
    
    /**runs the application to enable registration of users
     * 
     */
public void start(){
   setUpDisplay();
    registerEventHandlers();  
}
    private void registerEventHandlers() {
        sumbitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (isAnyFieldEmpty() == false) {//all fields were filled
                    int sn = databaseAccess.getNumberOfRows() + 1;
                    String user = "default";
                    if(databaseAccess.getFileDirectory().equals("src\\com\\maihanks\\Resources\\Database\\OverseerBiodata.txt")){
                       user = "admin" ;
                    }else{
                        user="user";
                    }
                    String details[] = {textField[0].getText(), textField[1].getText(), user + sn, ManipulateFormElements.getContentOfPasswordField(password)};

                    String record = textField[0].getText() + databaseAccess.getDelimeter() + textField[1].getText() + databaseAccess.getDelimeter() + details[2] + databaseAccess.getDelimeter() + details[3];
                     registerClient(record);//sends the cilent's record to the appropriate database
                    JOptionPane.showMessageDialog(null, "Registration was successful your details are : \n\n" + "First Name :"+details[0]+"\nLast Name :"+details[1]+"\nUsername : "+details[2]+"\nPassword : "+details[3]+"\nPlease ensure you keep your username and password safe\nyou will need them to login subsequently");
                }//end if
                else{//the fields are empty
                      JOptionPane.showMessageDialog(null, "Please no field can be left empty, fill up the fields and proceed to submit");
                }
            }
        });
        adminHomeButton.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
               AdminHome adminHome = new AdminHome(null);
               adminHome.start(); 
               dispose();
            }
        });
              
    }
/**
 * verifies if any of the fields is empty
 * @return 
 */
    private boolean isAnyFieldEmpty() {
        boolean status = true;
        if ((!textField[0].getText().equals("") && (!textField[0].getText().equals(null)))
                && (!textField[1].getText().equals("") && (!textField[1].getText().equals(null)))
                && (!ManipulateFormElements.getContentOfPasswordField(password).equals("") && !ManipulateFormElements.getContentOfPasswordField(password).equals(null))) {
            status = false;
        }
        return status;
    }
/**
 * sets up the display
 */
    private void setUpDisplay() {
        parentPanel.setBounds(70, 70, 250, 200);
        parentPanel.setLayout(new GridLayout(5, 2));

        parentPanel.add(descriptionLabel[0]);
        parentPanel.add(textField[0]);
        parentPanel.add(descriptionLabel[1]);
        parentPanel.add(textField[1]);
        parentPanel.add(descriptionLabel[2]);
        parentPanel.add(password);

        parentPanel.add(adminHomeButton);
        parentPanel.add(sumbitButton);

        super.add(parentPanel);
        super.setVisible(true);
    }

    public static void main(String[] args) {
        RegisterClient registerClient = new RegisterClient("src\\com\\maihanks\\Resources\\Database\\OverseerBiodata.txt");
         registerClient.start();
        
    }
}
