/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.maihanks.pupilAssistant;

import com.maihanks.FileDatabaseManager.Database;
import java.awt.Color;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;

/**
 *
 * 
 */
public class Home extends JFrame {

    Login login;

    public Home() {
    }//end GameHomeDesign();

    /**
     * verifies if at-least one overseer has been registered
     *
     * @return
     */
    private boolean doesAnyOverseerExist() {
        boolean status = false;
        Database OverseerDatabaseAccess = new Database("src\\com\\maihanks\\Resources\\Database\\OverseerBiodata.txt");
        if (OverseerDatabaseAccess.getNumberOfRows() >= 1) {
            status = true;
        }
        return status;
    }//end doesAnyOverseerExist()

    /**
     * launches the application
     */
    public void launchApp() {
        if (doesAnyOverseerExist() == false) {// no existing admin(Overseer) Application lauches for the very first time
            JOptionPane.showMessageDialog(null, "Welcome, Please click ok to proceed registration \nas the administrator for this program");
            RegisterClient registerClient = new RegisterClient("src\\com\\maihanks\\Resources\\Database\\OverseerBiodata.txt");
            registerClient.start();
        } else {
            login = new Login();
            login.start();
            /*if (login.getLoginSucess() == true) {

             if ((login.getUsername().charAt(0) + "").equals("a")) { //user is admin
             AdminHome adminHome = new AdminHome(login);
             adminHome.start();
             login.dispose();
             } else { //user is pupil
             PupilHome pupilHome = new PupilHome(login);
             login.dispose();
             }
             } else {
             }*/
            // super.setVisible(true);
        }//end else
    }//end launchApp()

    public static void main(String[] args) {
        //"src%ncom%nmaihanks%nResources%nDatabase%nOverseerBiodata.txt"
        Home home = new Home();
        home.launchApp();
    }
}
