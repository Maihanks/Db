/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.maihanks.pupilAssistant;

import com.maihanks.FileDatabaseManager.Database;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 */
public class PupilHome extends JFrame {

    JTabbedPane mainMenuTabbedPane = new javax.swing.JTabbedPane(JTabbedPane.TOP);
    JPanel mainMenuTabbedPanePanels[] = new JPanel[5];//panels for coresponding tabbed pane
    JLabel mainMenuTabbedPaneTopLabel[] = new JLabel[5], mainMenuTabbedPaneBottomLabel[] = new JLabel[5], mainMenuTabbedPaneCenterLabel[] = new JLabel[5];
    Color mainMenuTabbedPaneColor = Color.WHITE.darker();// new Color(30,67,88);
    String username;
    private JButton takeTestButton  = new JButton("Take Test"), viewStatisticsButton  = new JButton("Statistics"), logoutButton = new JButton("logout");
    private JPanel topPanel = new JPanel(), topMiddlePanel = new JPanel(),bottomMiddlePanel = new JPanel(),bottomPanel =  new JPanel();
    private JPanel parentPanel = new JPanel();
    private JFrame parentFrame = new JFrame("Pupil tutor");
    public PupilHome(String theUsername) {
        username = theUsername;
        parentFrame.setBounds(250, 50, 1000, 600);
        parentFrame.setLayout(null);
        parentFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setUpMainMenuTabbedPane();
        parentFrame.add(parentPanel);
        parentFrame.setResizable(false);
    } 

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
   public void setUpMainPanels(){
    parentPanel.setLayout(null);
    parentPanel.setBounds(0, 0, 1000, 600);
    topPanel.setBackground(Color.DARK_GRAY);
    topPanel.add(takeTestButton);
    topPanel.add(viewStatisticsButton);
    topPanel.add(logoutButton);
    topPanel.setBounds(0, 0, parentPanel.getWidth(), parentPanel.getHeight() * 6/100);
    parentPanel.add(topPanel);
    
    
    topMiddlePanel.setBackground(Color.DARK_GRAY);
    JLabel welcomeMessageLabel = new JLabel("Welcome , "+username);
    welcomeMessageLabel.setForeground(Color.WHITE);
    topMiddlePanel.setBounds(0, topPanel.getHeight(), parentPanel.getWidth(), parentPanel.getHeight()/10);
    topMiddlePanel.setLayout(null);
    welcomeMessageLabel.setBounds(topMiddlePanel.getWidth()/2, 0, topMiddlePanel.getWidth()/2,40);
    topMiddlePanel.add(welcomeMessageLabel);
    parentPanel.add(topMiddlePanel);
    
    
    bottomMiddlePanel.setBackground(Color.black);
    bottomMiddlePanel.add(new javax.swing.JLabel( new javax.swing.ImageIcon("src\\com\\maihanks\\Resources\\images\\africanchild.jpg"))); 
    bottomMiddlePanel.setBounds(0, topPanel.getHeight(), parentPanel.getWidth(), parentPanel.getHeight() * 8/10);
    parentPanel.add(bottomMiddlePanel);
    
    bottomPanel.setBackground(Color.WHITE);
    JLabel copyRightLabel = new JLabel("Copy right Abel 2016");
    bottomPanel.add(new javax.swing.JLabel( new javax.swing.ImageIcon("src\\com\\maihanks\\Resources\\images\\africanchild.jpg"))); 
    bottomPanel.setBounds(0, 520, parentPanel.getWidth(), 10);
    bottomPanel.setLayout(null);
    copyRightLabel.setBounds(bottomPanel.getWidth()/2, 0, bottomPanel.getWidth()/2,bottomPanel.getHeight());
    bottomPanel.add(copyRightLabel);
    parentPanel.add(bottomPanel);
    }
    private void setUpMainMenuTabbedPane() {
        setUpMainPanels();
       takeTestButton.setIcon(new javax.swing.ImageIcon("src\\com\\maihanks\\Resources\\images\\Favorite.png"));
       viewStatisticsButton.setIcon(new javax.swing.ImageIcon("src\\com\\maihanks\\Resources\\images\\Donate.png"));
    }//end setUpMainMenuTabbedPane()

    /**
     * sets up the tabbedPanes
     */
    private void setUpMainMenuTabbePanePanels() {
        setUpMainMenuTabbedPaneCenterLabels();
        for (int a = 0; a < mainMenuTabbedPanePanels.length; a++) {
            mainMenuTabbedPanePanels[a] = new JPanel();
            mainMenuTabbedPanePanels[a].setBackground(mainMenuTabbedPaneColor);
            if( a!=2){
            mainMenuTabbedPanePanels[a].add(mainMenuTabbedPaneCenterLabel[a]/*, BorderLayout.CENTER*/);
            }
        }//end for loop
        JLabel imageLabel = new JLabel();
        imageLabel.setIcon(new ImageIcon("src\\com\\maihanks\\Resources\\images\\africanchild.jpg"));

        JLabel developerImageLabel = new JLabel();
        developerImageLabel.setIcon(new ImageIcon("images\\abel.JPG"));
        mainMenuTabbedPanePanels[3].add(developerImageLabel);
        setUpStatisticsTabbedPane();
    }

    private void setUpMainMenuTabbedPaneCenterLabels() {
        mainMenuTabbedPaneCenterLabel[0] = new JLabel("Please Select Subject");
        mainMenuTabbedPaneCenterLabel[1] = new JLabel("To take a test click ");
        mainMenuTabbedPaneCenterLabel[3] = new JLabel("Developer\n"
                + "This Program is intended to test and improve the pupil's skills in mathematics and general studies\n"
                + "                                    and to also familiarized the pupil with the computer system");
        mainMenuTabbedPaneCenterLabel[4] = new JLabel("Exit Section");
    }//end setUpMainMenuTabbedPaneCenterLabels()

    public void start() {
        setUpEventHandlers();
        parentFrame.setVisible(true);
    }

    private void setUpEventHandlers() {
                takeTestButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                TakeTestHome takeTestHome = new TakeTestHome(username);
                takeTestHome.launch();
             parentFrame.dispose();
            }
        });

                viewStatisticsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ViewSinglePupilStatistics viewSinglePupilStatistics = new ViewSinglePupilStatistics(username);
                viewSinglePupilStatistics.display();
                parentFrame.dispose();
            }
        });     
                
           logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Login login = new Login();
                login.start();
             parentFrame.dispose();
            }
        });  
           
    }
    private void setUpStatisticsTabbedPane() {
        int columnPosition = 1; 
        String searchKey = username;
        JTable table = new JTable();
        DefaultTableModel model =  new DefaultTableModel();
        String [] columnHeaders = {};
        Database databaseAccess = null;
        String []allRecords = null;
         JPanel statisticsPanel = new JPanel();
         String[] columns = {"First Name  ", "Last Name ", "User name", "password "};
        
     
//        mainMenuTabbedPanePanels[2].add(scroll);
    }
    public static void main(String[] args) {
        PupilHome pupilHome = new PupilHome("user2");
        //JOptionPane.showMessageDialog(null, pupilHome.getUsername());
       pupilHome.start();  
        //JOptionPane.showMessageDialog(null, "user on session :\n"+pupilHome.getUsername());
    }//end main()
}
