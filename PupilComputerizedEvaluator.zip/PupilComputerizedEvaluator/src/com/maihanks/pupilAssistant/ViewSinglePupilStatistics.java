/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.maihanks.pupilAssistant;

import com.maihanks.FileDatabaseManager.Database;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

/**
 *
 * @author MAIHANKS
 */
public class ViewSinglePupilStatistics {

    private String username;
    private JFrame parentFrame = new JFrame("Pupil Tutor");
    private JTable table;
    private String[] columns = {"First Name  ", "Last Name ", "User name", "password "};
    private JPanel menuPanel = new JPanel();
    private JPanel tablePanel = new JPanel();
    private JPanel parentPanel = new JPanel();
    private JButton homeButton = new JButton("home"), logoutButton = new JButton("logout");
    private JLabel currentUserDescriptionLabel;
    public ViewSinglePupilStatistics(String theUsername) {
        username = theUsername;
        parentFrame.setBounds(250, 50, 1000, 600);
        parentFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        parentFrame.setResizable(false);
        setUpParentFrameComponents();
        setUpEventHandlers();
    }

    public String getUsername() {
        return username;
    }

    private void setUpParentFrameComponents() {
        
        
        
        ViewRecord viewPupiilPerfomanceRecord = new ViewRecord("src\\com\\maihanks\\Resources\\Database\\OverseerBiodata.txt", columns);
        table = viewPupiilPerfomanceRecord.viewSinglePupilPerformanceRecordTable(this.getUsername());
        table.setBackground(Color.WHITE.darker());
        JScrollPane scroll = new JScrollPane(table);
        
        
        
        parentFrame.setLayout(new GridLayout(1,1));
        parentPanel.setLayout(null);
        parentPanel.setBackground(Color.DARK_GRAY);
        
        
        menuPanel.setBounds(0, 0, 1000,50);
        menuPanel.setLayout(null);
        menuPanel.setBackground(Color.DARK_GRAY);
        homeButton.setBounds(20, 3, 150,40);
        logoutButton.setBounds(200, 3, 150,40);
        Database databaseAccess = new Database("src\\com\\maihanks\\Resources\\Database\\pupilsBiodata.txt");
        String[] singleRowValues = databaseAccess.getAllRowsWithAttributeMatch(2, username);
        String[] userAttributes =  databaseAccess.getSingleRowAttributes(singleRowValues[0]);
        
        currentUserDescriptionLabel = new JLabel(userAttributes[0]+" "+userAttributes[1]+", Result Statistics");
        currentUserDescriptionLabel.setBounds(400, 3, 300,40);
        currentUserDescriptionLabel.setForeground(Color.WHITE);
        
        menuPanel.add(homeButton);
        menuPanel.add(logoutButton);
        menuPanel.add(currentUserDescriptionLabel);
        
        tablePanel.setBounds(0, 50, 1000, 500);
        tablePanel.setLayout(new GridLayout(1, 1));
        tablePanel.add(scroll);
        
        parentPanel.add(menuPanel);
        parentPanel.add(tablePanel);
        parentFrame.add(parentPanel);
    }
private void setUpEventHandlers() {
        homeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                PupilHome pupilHome = new PupilHome(username);
                pupilHome.start();
                parentFrame.dispose();
            }
        });
        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Login login = new Login();
                login.start();
                parentFrame.dispose();
            }
        });
    }
    public void display() {
        parentFrame.setVisible(true);
    }
    
    public static void main(String[] args){
    ViewSinglePupilStatistics viewSinglePupilStatistics = new ViewSinglePupilStatistics("user1");
    viewSinglePupilStatistics.display();
    }
}
