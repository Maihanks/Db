/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.maihanks.FileDatabaseManager;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author MAIHANKS
 * Data : 01/06/2015
 */
public class ReadFromFile {

    private String[] content = new String[10];
    private String directory;
    private ArrayList<String> fileContent;

    public ReadFromFile(String dir) {
        directory = dir;
        fileContent = new ArrayList<>();
    }

    /**
     * This method returns an arrayList where each element is a row in the file
     * 
     */
    public ArrayList<String> getFileContent() //copies the fileContent of the file into array fileContent
    {
        FileReader FileReaderObj = null;
        BufferedReader BufferedReaderObj = null;
        //String directory = "c:\\bsu\\cmp315.txt";"C:\\Users\\MAIHANKS\\Documents\\NetBeansProjects\\MyProjects\\src\\useFile\\myFile.txt"; 
        try {
            File name = new File(directory);
            FileReaderObj = new FileReader(name);
            BufferedReaderObj = new BufferedReader(FileReaderObj);
            while (BufferedReaderObj.ready()) {
                fileContent.add(BufferedReaderObj.readLine());
            }//end while                   
        BufferedReaderObj.close();
        } catch (FileNotFoundException ex) {
            //Logger.getLogger(WriteToFile.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null,"Error file not found");
            //System.exit(1);
        } catch (IOException ex) {
            //Logger.getLogger(WriteToFile.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null,"Error cannot access file");
            //System.exit(1);
        }    
        return fileContent;
    }//end getFileContent()
    
}//end class ReadFromFile
