/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */

import java.io.*;
import java.math.*;
import java.security.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.*;
import java.util.stream.IntStream;
public class FormingMagicSquareSolution {

    // Complete the formingMagicSquare function below.
    static int formingMagicSquare(int[][] s) {
    /* Programmer: Munura Maihankali (Maihanks)
         * Email: maihankspinas@gmail.com, Tel: +2348068816818
         * Find code comments after the return statement
         */
         int[][] magicSquareA = {{8, 3, 4}, {1, 5, 9}, {6, 7, 2}}, magicSquareB = {{6, 1, 8}, {7, 5, 3}, {2, 9, 4}}, magicSquareC = {{2, 7, 6}, {9, 5, 1}, {4, 3, 8}}, magicSquareD = {{4, 9, 2}, {3, 5, 7}, {8, 1, 6}},
                 magicSquareE = {{4, 3, 8}, {9, 5, 1}, {2, 7, 6}}, magicSquareF = {{2, 9, 4}, {7, 5, 3}, {6, 1, 8}}, magicSquareG = {{6, 7, 2}, {1, 5, 9}, {8, 3, 4}}, magicSquareH = {{8, 1, 6}, {3, 5, 7}, {4, 9, 2}};
         Object[] allMagicSquares = {magicSquareA, magicSquareB, magicSquareC, magicSquareD, magicSquareE, magicSquareF, magicSquareG, magicSquareH};
         int currentCost = 0, minimumCost = 0;         
         int[][] theCurrentMagicSquare;
         int[] costs = new int[allMagicSquares.length];/*An array for storing all costs wrt all posible magic squares*/
         for (int x = 0; x < allMagicSquares.length; x++) {/* iterate through all posible magic squares */
             theCurrentMagicSquare = (int[][]) allMagicSquares[x]; /**/
             for (int a = 0; a < 3; a++) {/*iterate through row*/
                 for (int b = 0; b < 3; b++) {/*iterate through columns of the current row */                    
                     currentCost = currentCost + Math.abs(s[a][b] - theCurrentMagicSquare[a][b]);                  
                 }
             }             
             costs[x] = currentCost;
             currentCost = 0; /*reinitializes the currentCost to zero*/
         }
minimumCost  =  IntStream.of(costs).min().getAsInt();/* the minimum cost of all costs*/
 return minimumCost;
 /** All possible magic squares are stored in different 3 X 3 arrays - i.e magicSquareA, magicSquareB...magicSquareH
  * These magic squares are further stored in an array of Object -allMagicSquares, to enable collective processing
  * for each magic square, cost wrt to the matrix s[][] is generated
  * These costs are further stored in the costs array where the smallest value of them is evaluated as the minimum cost
  */

    }

    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) throws IOException {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(System.getenv("OUTPUT_PATH")));

        int[][] s = new int[3][3];

        for (int i = 0; i < 3; i++) {
            String[] sRowItems = scanner.nextLine().split(" ");
            scanner.skip("(\r\n|[\n\r\u2028\u2029\u0085])?");

            for (int j = 0; j < 3; j++) {
                int sItem = Integer.parseInt(sRowItems[j]);
                s[i][j] = sItem;
            }
        }

        int result = formingMagicSquare(s);

        bufferedWriter.write(String.valueOf(result));
        bufferedWriter.newLine();

        bufferedWriter.close();

        scanner.close();
    }
}
