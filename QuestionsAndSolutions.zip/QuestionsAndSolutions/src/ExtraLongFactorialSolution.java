/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */

import java.io.*;
import java.math.*;
import java.security.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.*;

public class ExtraLongFactorialSolution {

    // Complete the extraLongFactorials function below.
    static void extraLongFactorials(int n) {
        BigInteger longFactorial =  BigInteger.valueOf(1) ;
        for (int counter = n; counter >= 1; counter--) {
            longFactorial = longFactorial.multiply(BigInteger.valueOf(counter));
        }
        System.out.println(longFactorial);

    }

    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        int n = scanner.nextInt();
        scanner.skip("(\r\n|[\n\r\u2028\u2029\u0085])?");

        extraLongFactorials(n);

        scanner.close();
    }
}