/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */

import java.io.*;
import java.math.*;
import java.security.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.*;
import java.util.regex.*;
import java.util.stream.*;
import static java.util.stream.Collectors.joining;
import static java.util.stream.Collectors.toList;

public class BonApetitSolution {

    // Complete the bonAppetit function below.
    static void bonAppetit(List<Integer> bill, int k, int b) {
       /* Programmer: Munura Maihankali (Maihanks)
         * Email: maihankspinas@gmail.com, Tel: +2348068816818
         * Find code comments after the return statement
         */
        int anna_Bill = 0;
        for (int a = 0; a < bill.size(); a++) if (a != k) anna_Bill = anna_Bill + bill.get(a);                            
        anna_Bill = anna_Bill/2;/*Anna accurate bill*/
        if(anna_Bill == b ) System.out.println("Bon Appetit");/**/
        else{ int arreas = b - anna_Bill;
            System.out.println(arreas);
        }

    }

    public static void main(String[] args) throws IOException {
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));

        String[] nk = bufferedReader.readLine().replaceAll("\\s+$", "").split(" ");

        int n = Integer.parseInt(nk[0]);

        int k = Integer.parseInt(nk[1]);

        List<Integer> bill = Stream.of(bufferedReader.readLine().replaceAll("\\s+$", "").split(" "))
            .map(Integer::parseInt)
            .collect(toList());

        int b = Integer.parseInt(bufferedReader.readLine().trim());

        bonAppetit(bill, k, b);

        bufferedReader.close();
    }
}
