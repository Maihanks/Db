/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */

import java.io.*;
import java.math.*;
import java.security.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.*;
import java.util.regex.*;
import java.util.stream.*;
import static java.util.stream.Collectors.joining;
import static java.util.stream.Collectors.toList;

public class MigratoryBirdsSolution {

    // Complete the migratoryBirds function below.
static int migratoryBirds(List<Integer> arr) {
/* Programmer: Munura Maihankali (Maihanks)
         * maihankspinas@gmail.com
         * Find comments after the return statement
 */
List<Integer> highestFrequencyTallyingBirds = new ArrayList<Integer>(); int smallestBirdTypeWithHihestFrequency =0; int[] BirdTypes = {1,2,3,4,5}; int[] BirdTypesFrequency = new int[5];//the frequency of the 5 bird types, 1, 2,3 , 4, 5
        for (int counter = 0; counter < arr.size(); counter++) { // generates the frequency of each bird type in the list
            if (arr.get(counter).equals(Integer.valueOf(BirdTypes[0])))          BirdTypesFrequency[0]++;  
            else if ( arr.get(counter).equals(Integer.valueOf(BirdTypes[1] ))  ) BirdTypesFrequency[1]++;
            else if ( arr.get(counter).equals(Integer.valueOf(BirdTypes[2] ))  ) BirdTypesFrequency[2]++;
            else if ( arr.get(counter).equals(Integer.valueOf(BirdTypes[3] ))  ) BirdTypesFrequency[3]++;  
            else BirdTypesFrequency[4]++;  }

        int largestFrequencyValue = BirdTypesFrequency[0];
        for (int a = 1; a < BirdTypesFrequency.length; a++) { if (largestFrequencyValue < BirdTypesFrequency[a])  largestFrequencyValue = BirdTypesFrequency[a];}  
        for (int p = 0; p < BirdTypesFrequency.length; p++) { if (BirdTypesFrequency[p] == largestFrequencyValue) highestFrequencyTallyingBirds.add(BirdTypes[p]); }
        smallestBirdTypeWithHihestFrequency = highestFrequencyTallyingBirds.get(0);//
        if (highestFrequencyTallyingBirds.size() > 1) {//if there are more than one bird with the highest tallying frequencies
            for (int x = 1; x < highestFrequencyTallyingBirds.size(); x++) {  if (smallestBirdTypeWithHihestFrequency > highestFrequencyTallyingBirds.get(x)) smallestBirdTypeWithHihestFrequency = highestFrequencyTallyingBirds.get(x);  }  }
        return smallestBirdTypeWithHihestFrequency;
    /*The first for loop generates the frequency of each bird by incrementing the corresponding BirdTypesFrequency where index 0 represents bird ty 1 index respectively
     * The second for loop statement evaluates the highest frequency value in the distribution
     * The Third for loop appends the the bird types whose frequencies tally with the highest frequency
     * If there are more than bird whose frequencies tally the highest frequency value the Fouth for loop and condition evaluates the smallest bird type value with a corresponding highest frequency.
     */

    }

    public static void main(String[] args) throws IOException {
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(System.getenv("OUTPUT_PATH")));

        int arrCount = Integer.parseInt(bufferedReader.readLine().trim());

        List<Integer> arr = Stream.of(bufferedReader.readLine().replaceAll("\\s+$", "").split(" "))
            .map(Integer::parseInt)
            .collect(toList());

        int result = migratoryBirds(arr);

        bufferedWriter.write(String.valueOf(result));
        bufferedWriter.newLine();

        bufferedReader.close();
        bufferedWriter.close();
    }
}
