/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */

import java.io.*;
import java.math.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;

public class TimeConversionSolution {

    /*
     * Complete the timeConversion function below.
     */
    static String timeConversion(String s) {
        /* Programmer: Munura Maihankali (Maihanks)
         * Email: maihankspinas@gmail.com, Tel: +2348068816818
         * Find code comments after the return statement
         */
    String militaryTimeFormat = "", hourComponent = s.substring(0, 2),minuteComponent = s.substring(3, 5),secondComponent = s.substring(6, 8),
            AM_and_PM = s.substring(8, 10) ;
    if(AM_and_PM.equals("AM")){
    if(hourComponent.equals("12")) hourComponent = "00";}else{
    if(Integer.parseInt(hourComponent) < 12){// time is 01:00 pm above in normal time
    int h = 12 + Integer.parseInt(hourComponent);    hourComponent = h+""; 
    if(hourComponent.length()!=2) hourComponent = "0"+hourComponent;}    
    }
    militaryTimeFormat = hourComponent+":"+minuteComponent+":"+secondComponent;                    
    return militaryTimeFormat;
    /**First all, The hour,minute,second and Am_PM components are first extracted from the time string
     * The distinct hour of 12 AM is first deduced in military time as 00 AM, all other cases of AM time are the same in both time conventions
     * if the hour time is in pm (i.e x = 1pm,2pm,3pm....11 pm) in normal time, the military equivalent is deduced as (12 + x) pm
     */

    }

    private static final Scanner scan = new Scanner(System.in);

    public static void main(String[] args) throws IOException {
        BufferedWriter bw = new BufferedWriter(new FileWriter(System.getenv("OUTPUT_PATH")));

        String s = scan.nextLine();

        String result = timeConversion(s);

        bw.write(result);
        bw.newLine();

        bw.close();
    }
}
