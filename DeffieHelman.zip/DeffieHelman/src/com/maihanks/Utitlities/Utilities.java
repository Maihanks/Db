/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.maihanks.Utitlities;

import java.util.Random;

/**
 *
 * @author MAIHANKS
 */
public class Utilities {

    static DateAndTime dateAndTime = new DateAndTime();
    static Random rand = new Random();

    public Utilities() {
    }

    public static String generateUniqueNumberWRT_Time() {
        String uniqueNumber = rand.nextDouble() + dateAndTime.getCurrentYear() + dateAndTime.getCurrentMonth() + dateAndTime.getCurrentDayDate() + dateAndTime.getCurrentHour() + dateAndTime.getCurrentMinute() + dateAndTime.getCurrentSecond() + dateAndTime.getCurrentMilliSecond();
        return uniqueNumber;
    }

    public static boolean isNumberPrime(int number) {
        boolean status = false;
//        System.out.print(number+" = ");
        if (number == 2 || number == 3) {
            status = true;
        } else {
            for (int a = 2; a <= number / 2; a++) {
                if ((number % a) == 0) {
                    status = false;
                    break;
                } else {
                    status = true;
                }

            }
        }
        return status;
    }

    public static int generateNextPrime(int lowerBound) {
        int prime = 0;
        if (lowerBound % 2 == 0) {
            lowerBound = lowerBound + 1;
        } else {
            lowerBound = lowerBound + 2;
        }

        for (int num = lowerBound; num <= 879839; num += 2) {
            if (Utilities.isNumberPrime(num)) {
                prime = num;
                break;
            }
        }
        return prime;
    }

    public static double getAverage(int[] numbers) {
        double average = 0;
        int sum = 0, n = numbers.length;

        for (int a = 0; a < numbers.length; a++) {
            sum = sum + numbers[a];
        }
        System.out.println("sum = " + sum);
        System.out.println("f = " + n);
        average = sum / n;

        return average;
    }

    public static void main(String[] args) {
        //    System.out.println(generateUniqueNumberWRT_Time());
//        for(int b = 4; b<=50; b++){
//        System.out.println(isNumberPrime(b));
//        }
        int[] n = {1, 2, 3, 4, 10};
        System.out.println(Utilities.getAverage(n));
//        System.out.println(Utilities.generateNextPrime(17));
    }
}
