/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.maihanks.Utitlities;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.StringTokenizer;

/**
 *
 * @author MAIHANKS
 */
public class DateAndTime implements Serializable {

    private int[] a = new int[3];
    private String currentDate;
    private String currentMilliSecond, currentSecond, currentMinute, currentHour, currentDay, currentMonth, currentYear;

    public DateAndTime() {
        evaluateDateAndTime();
    }//end DateAndTime()

    /**
     * evaluates the current date and time
     *
     */
    private void evaluateDateAndTime() {
        Date date1 = new Date(), date2 = new Date();//gets today's date
        //formats today's date
        SimpleDateFormat formatdate = new SimpleDateFormat("d/MM/YYYY");
        currentDate = formatdate.format(date1);//todays date

        StringTokenizer token = new StringTokenizer(currentDate, "/");//tokeenizes the date
        int age = 0;
        int i = 0;
        while (token.hasMoreTokens()) {
            a[i] = Integer.parseInt(token.nextToken());//gets each component- day, month, year
            i++;
        }//end while
        currentDay = a[0] + "";
        currentMonth = a[1] + "";
        currentYear = a[2] + "";
        //evaluates the time

        SimpleDateFormat formatTime = new SimpleDateFormat("S/s/m/h");
        String todaysDate2 = formatTime.format(date2);//current timeComponents in seconds
        StringTokenizer token2 = new StringTokenizer(todaysDate2, "/");//tokeenizes the date 

        int counter = 0;
        while (token2.hasMoreTokens()) {
            if (counter == 0) {
                this.currentMilliSecond = token2.nextToken();
            } else if (counter == 1) {
                this.currentSecond = token2.nextToken();
            } else if (counter == 2) {
                this.currentMinute = token2.nextToken();
            } else if (counter == 3) {
                this.currentHour = token2.nextToken();
            }//end else if

            counter += 1;//increments counter
        }

    }//end evaluateDateAndTime()

    /**
     * returns today's date as a string where the day, month and year are digits
     * separated by "/"
     */
    public String getCurrentDate() {
        return currentDate;
    }

    /**
     * returns the digit that represent the date of today in the current month,
     * the month and year faction are ignored i.e if the current date is x/y/z,
     * this method returns x
     *
     * @return
     */
    public String getCurrentDayDate() {
        return currentDay;
    }//end getTodaysYear()

    /**
     * returns a digit that represents today's month
     *
     * @return
     */
    public String getCurrentMonth() {
        return currentMonth;
    }//end getTodaysYear()

    /**
     * returns a digit that represents today's year
     *
     * @return
     */
    public String getCurrentYear() {
        return currentYear;
    }//end getTodaysYear()

    /**
     * returns the current miliseconds
     *
     * @return
     */
    public String getCurrentMilliSecond() {
        return this.currentMilliSecond;
    }

    /**
     * returns the current second
     *
     * @return
     */
    public String getCurrentSecond() {
        return this.currentSecond;
    }

    /**
     * returns the current minute
     *
     * @return
     */
    public String getCurrentMinute() {
        return this.currentMinute;
    }

    /**
     * returns the current hour
     *
     * @return
     */
    public String getCurrentHour() {
        return this.currentHour;
    }
//    public static void main(String [] args){
//DateAndTime dt = new DateAndTime();
//        System.out.println(dt.getCurrentMilliSecond());
//        System.out.println(dt.getCurrentSecond());
//        System.out.println(dt.getCurrentMinute());
//        System.out.println(dt.getCurrentHour());
//        System.out.println(dt.getCurrentDayDate());
//        System.out.println(dt.getCurrentMonth());
//        System.out.println(dt.getCurrentYear());
//        System.out.println(dt.getCurrentDate());
//    }
}
