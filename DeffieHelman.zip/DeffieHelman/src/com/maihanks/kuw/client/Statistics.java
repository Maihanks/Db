package com.maihanks.kuw.client;

import deffiehelman.DeffieHelman;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author MAIHANKS
 */
public class Statistics {

    private DefaultTableModel model;
    private String username;
    private JFrame parentFrame = new JFrame("Statistics");
    private JTable table;
    private String[] columns = {"My Variables and states", "Spying Third Party"};
    private JPanel menuPanel = new JPanel();
    private JPanel tablePanel = new JPanel();
    private JPanel parentPanel = new JPanel();
    private JLabel currentUserDescriptionLabel;
    Client client;

    public Statistics(Client theClient) {
        client = theClient;
        parentFrame.setBounds(250, 50, 1000, 600);
        parentFrame.setResizable(false);
        setUpParentFrameComponents();
        setUpEventHandlers();
    }

    public String getUsername() {
        return username;
    }

    private void setUpParentFrameComponents() {
        table = new JTable();
        model = new DefaultTableModel();

        String percentageValues[] = new String[columns.length];

        model.setColumnIdentifiers(columns);
        table.setModel(model);
        String[] rows = new String[2];
        rows[0] = "Modulo , P = " + DeffieHelman.p + ", Generator g = " + DeffieHelman.g;
        rows[1] = " Unknown";
        model.addRow(rows);
        rows[0] = " my secret Key , a = " + client.sNumberA;
        rows[1] = " Unknown";
        model.addRow(rows);
        rows[0] = " secret key of the other client , b = ? ";
        rows[1] = " Unknown";
        model.addRow(rows);
        rows[0] = "My dummy key A = g^a mod P =  " + DeffieHelman.generateCryptoKey(client.sNumberA);
        rows[1] = " Can be Intercepted , " + DeffieHelman.generateCryptoKey(client.sNumberA);
        model.addRow(rows);
        rows[0] = "received dummy key (B), B =  " + client.receivedKeyTextField.getText();
        rows[1] = "Unknown";
        model.addRow(rows);

        rows[0] = "generated key (K = (ga mod p)b mod p = gab mod p ), K =  " + DeffieHelman.getCommonKey();
        rows[1] = "Unknown";
        model.addRow(rows);

        table.setBackground(Color.WHITE.darker());

//        Statistics statistics = new Statistics("src\\com\\maihanks\\Resources\\Database\\OverseerBiodata.txt", columns);
        table.setBackground(Color.WHITE.darker());
        JScrollPane scroll = new JScrollPane(table);



        parentFrame.setLayout(new GridLayout(1, 1));
        parentPanel.setLayout(null);
        parentPanel.setBackground(Color.DARK_GRAY);


        menuPanel.setBounds(0, 0, 1000, 50);
        menuPanel.setLayout(null);
        menuPanel.setBackground(Color.DARK_GRAY);

        currentUserDescriptionLabel = new JLabel("Diffie-Hellman, " + ", Result Analysis");
        currentUserDescriptionLabel.setBounds(400, 3, 300, 40);
        currentUserDescriptionLabel.setForeground(Color.WHITE);

        menuPanel.add(currentUserDescriptionLabel);

        tablePanel.setBounds(0, 50, 1000, 500);
        tablePanel.setLayout(new GridLayout(1, 1));
        tablePanel.add(scroll);

        parentPanel.add(menuPanel);
        parentPanel.add(tablePanel);
        parentFrame.add(parentPanel);
    }

    private void setUpEventHandlers() {
    }

    public void display() {
        parentFrame.setVisible(true);
    }
//    public static void main(String[] args){
//    Statistics statistics = new Statistics(null);
//    statistics.display();
//    }
}
