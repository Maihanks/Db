/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.maihanks.kuw.client;

import com.maihanks.Utitlities.DateAndTime;
import com.maihanks.kuw.general.Message;
import java.io.File;
import java.io.Serializable;

/**
 *
 * @author MAIHANKS
 */
public class ClientMessage implements Serializable, Message {

    private String sender, receiver, messageSendingDate, messageSendingTime, messageReceivingDate;
    private String[] message;
    private File fileMessage;
    /*the contents of the message can any any of the following distinct form:
     *-login request {username,password,usercategory}
     * -create new staff user profile {username,password,names,sex,role,deptCode}
     * -create new student user profile {username/matno,password,names,sex,deptCode}      
     * -create new user profile profile{username,password,names,sex,role,}
     * -input scores {coursecode }
     * -view scores {coursecode,score}
     * -update profile{username,password,names,sex,role,}
     */
    /**
     * defines the message type to enable appropriate response from the server
     */
//public static enum MessageType {* a normal message*/NORMAL_MESSAGE,/**a request message that prompts validating user */LOGIN_REQUEST,
    /**
     * a request message that prompts the server to register user
     * REGISTER_USER};
     */
    private int theMessageType;           
    public static final int MESSAGE_TYPE_CONNECTION_TERMINATED = 1,MESSAGE_TYPE_SEND_MY_KEY_REQUEST = 39,KEY_RECEIVED = 40, MESSAGE_TYPE_SEND_MESSAGE_REQUEST = 41;
    private transient DateAndTime dateAndTime;

    public ClientMessage(String theSender, String theReceiver, int theMessageType, String[] theMessage) {
        this.sender = theSender;
        this.receiver = theReceiver;
        this.theMessageType = theMessageType;
        this.message = theMessage;
        this.dateAndTime = new DateAndTime();
        this.messageSendingDate = dateAndTime.getCurrentDate();
    }

    public File getFileMessage() {
        return fileMessage;
    }

    public void setFileMessage(File fileMessage) {
        this.fileMessage = fileMessage;
    }

    private void analyzeIncomingMessage() {
    }//end analyzeIncomingMessage()

    public void setMesageReceivingDate(String theMessageReceivingDate) {
        this.messageReceivingDate = theMessageReceivingDate;
    }//end setMesageReceivingDate()

    @Override
    public String getSender() {
        return this.sender;
    }

    @Override
    public void setSender(String theSender) {
        this.sender = theSender;
    }

    @Override
    public String getReceiver() {
        return this.receiver;
    }

    @Override
    public String getMessageSendingDate() {
        return this.messageSendingDate;
    }

    @Override
    public String getMessageSendingTime() {
        return this.messageSendingTime;
    }

    @Override
    public String getMessageReceiveingDate() {
        return this.messageReceivingDate;
    }

    /**
     *
     * @return an array of string containing the segments of the message,the
     * size of the array is one if the message is not segmented
     */
    @Override
    public String[] getMessage() {
        return this.message;
    }

    /**
     * returns this message's type
     *
     * @return
     */
    public int getMessageType() {
        return theMessageType;
    }
}
