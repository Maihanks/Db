/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.maihanks.kuw.server;

import com.maihanks.kuw.general.Developers;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javax.swing.*;

/**
 *
 * @author MAIHANKS
 */
public class TheServer {

    JFrame parentFrame = new JFrame("SERVER");
    JPanel parentPanel = new JPanel();
    public static final int MAX_NUM_OF_CLIENTS = 10;//the maximum number of prospective clients to connect to this server
    JTextArea serverInfoDisplayArea = new JTextArea();
    private JTextField enterField = new JTextField();//text field to enter message
    private JTextArea displayArea = new JTextArea();//textarea to display sent and received messages
    private JTextArea developersDisplayArea = new JTextArea();//textarea to display sent and received messages
    private ObjectOutputStream output;//output stream
    private ObjectInputStream input;//input stream
    private ServerSocket server;//server
    private int port = 12345;//the port to listen for connection
    private Socket connection;//
    private int counter = 0;
    public ConnectedClients[] clients = new ConnectedClients[MAX_NUM_OF_CLIENTS];//instances of connected clients
    private ExecutorService threadExecutor = Executors.newFixedThreadPool(MAX_NUM_OF_CLIENTS);//enable multithreading capability            

    public TheServer() {
        setUpParentFrameComponents();
        parentFrame.setVisible(true);
    }

    public void setUpParentFrameComponents() {
        parentFrame.setBounds(200, 100, 500, 400);
        parentFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        parentFrame.setLayout(null);
        parentFrame.setResizable(false);


        parentPanel.setBounds(0, 0, parentFrame.getWidth(), parentFrame.getHeight());
        parentPanel.setLayout(null);
        parentPanel.setBackground(Color.DARK_GRAY.darker());


        setUpParentPanelComponents();
        parentFrame.add(parentPanel);
    }

    public void setUpParentPanelComponents() {
        displayArea.setBackground(Color.LIGHT_GRAY.brighter());
//    displayArea.setText("Launching Server.....\n"); 
//    displayArea.append("\n SERVER LAUNCHED SUCCESSFULLY!");
//    displayArea.append("\n                  SERVER DETAILS!");
        displayArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(displayArea);
        scrollPane.setBounds(0, 50, parentPanel.getWidth(), 250);

        serverInfoDisplayArea.setBounds(0, 0, parentPanel.getWidth(), 50);
        serverInfoDisplayArea.setBackground(Color.DARK_GRAY);
        serverInfoDisplayArea.setForeground(Color.WHITE);
        Font serverInfoDisplayAreaFont = new java.awt.Font(Font.SANS_SERIF, Font.BOLD + Font.ITALIC, 22);
        serverInfoDisplayArea.setFont(serverInfoDisplayAreaFont);

        serverInfoDisplayArea.setText("Launching Server.....\n");
        serverInfoDisplayArea.append("\n SERVER LAUNCHED SUCCESSFULLY!");

        //String t = serverInfoDisplayArea.getText();

        developersDisplayArea.setBounds(0, 300, parentPanel.getWidth(), 100);

        Font developersDisplayAreaFont = new java.awt.Font(Font.SANS_SERIF, Font.ITALIC, 14);
        developersDisplayArea.setFont(developersDisplayAreaFont);
        developersDisplayArea.setBackground(Color.black.brighter());
        developersDisplayArea.setForeground(Color.white);
        developersDisplayArea.append("Developed by : " + Developers.Munura);


        parentPanel.add(serverInfoDisplayArea);
        parentPanel.add(scrollPane);
        parentPanel.add(developersDisplayArea);
    }

    public void setUpEventHandlers() {
        enterField.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent event) {
                String msg = event.getActionCommand();
                String serverOutGoingMessage = "\nSERVER>>> " + event.getActionCommand();
                disseminateMessage(serverOutGoingMessage);
                displayArea.setEditable(true);
                displayArea.append("\nSERVER>>> " + event.getActionCommand() + "\n");//displays message on server's screen
                displayArea.setEditable(false);
            }
        });
    }

    /**
     * disseminates the message across all connected clients
     *
     * @param message
     */
    public void disseminateMessage(String message) {
        for (int a = 0; a < clients.length; a++) {//iterates through all clients
            try {
                clients[a].sendData(message);//sends message                    
            } catch (Exception ex) {
            }//end catch
        }//end for loop
    }//end diseminateMessage

    /**
     * sends message to a single client
     *
     * @param message
     * @param clientNum
     */
    public void sendMessageToSingleClient(String message, int clientNum) {
        try {
            clients[clientNum].sendData(message);//sends message 
        } catch (Exception ex) {
        }//end catch
    }//end sendMessageToSingleClient()

    /**
     * sends message to single client
     *
     * @param theClient
     * @param message
     */
    public void sendMessageToSingleClient(ConnectedClients theClient, String message) {
        theClient.sendData(message);//sends message   
    }//end sendMessageToSingleClient()

    /**
     * this method sends message to all connected clients excluding the sender
     * client
     *
     * @param theSenderClient
     * @param message
     */
    public void sendMessageToOtherClients(ConnectedClients theSenderClient, ServerMessage serverMessage) {
        for (int a = 0; a < clients.length; a++) {//iterates through all clients
            try {
                if (clients[a] != theSenderClient) {
                    clients[a].sendData(serverMessage);//sends message                    
                }
            } catch (Exception ex) {
            }//end catch
        }//end for loop

    }//end sendMessageToSingleClient()

    /**
     * Starts server
     */
    public void runServer() {
        try {
            server = new ServerSocket(port, MAX_NUM_OF_CLIENTS); //assigns port nujmber and num of clients
            displayArea.setEditable(true);
//            displayArea.append("\nIP Address : "+this.server.getInetAddress()+"");
//            displayArea.append("\nPort Number : "+this.server.getLocalPort()+"");            
            displayArea.append("\n WAITING FOR CONNECTIONS FROM CLIENTS\n");
            displayArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
            for (int a = 0; a < clients.length; a++) {//instantiates connected clients
                clients[a] = new ConnectedClients(this, server/*connection*/, displayArea, enterField, a);
                //public ConnectedClients(Server theParentServer,ServerSocket theServer/*Socket theConnection*/, JTextArea theDisplayArea, JTextField theEnterField, int theClientNo)
            }//end for loop

            while (counter < MAX_NUM_OF_CLIENTS) {//loops while designated number of clients is not reached
                try {
                    clients[counter].setClients(clients);
                    threadExecutor.execute(clients[counter]); //execute thread
                    counter++;
                } catch (Exception eofException) {
                    //clients[counter].displayMessage("\nServer terminated connection");
                    JOptionPane.showMessageDialog(null, "EOFException has occured");
                } /*finally {
                 clients[counter].closeConnection();
                 }//end finally*/
            }//end while

        } catch (IOException ioException) {
            System.err.println("IOException waiting for clients");
        }//end catch
    }//end runServer()
//    public static void main(String[] args) {
//        TheServer server = new TheServer();
//        server.runServer();
//    }
}
