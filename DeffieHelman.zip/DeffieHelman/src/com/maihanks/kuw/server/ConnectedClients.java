/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.maihanks.kuw.server;

import com.maihanks.kuw.client.ClientMessage;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

/**
 *
 * @author MAIHANKS
 */
public class ConnectedClients implements Runnable {

    private ObjectOutputStream output;
    private ObjectInputStream input;
    private Socket connection;
    private ServerSocket server;
    JTextArea displayArea;
    private JTextField enterField = new JTextField();
    private int clientNo;
    private ConnectedClients[] clients;
    private TheServer parentServer;
    int numberOfConnectedClients = 0;
    int numberOfKeysReceivedFromClients = 0;

    public ConnectedClients(TheServer theParentServer, ServerSocket theServer/*Socket theConnection*/, JTextArea theDisplayArea, JTextField theEnterField, int theClientNo) {
        parentServer = theParentServer;
        server = theServer;
        displayArea = theDisplayArea;
        enterField = theEnterField;
        clientNo = theClientNo;
    }

    public void setClients(ConnectedClients[] clients) {
        this.clients = clients;
    }

    public ObjectOutputStream getOutput() {
        return output;
    }

    public ObjectInputStream getInput() {
        return input;
    }

    private void waitForConnection() throws IOException {
        connection = server.accept();
        displayMessage(" connection  recieved from : " + connection.getInetAddress().getHostName() + ",  " + clientNo + "\n");
    }//end waitForConnection()

    private void getStreams() throws IOException {
        //JOptionPane.showMessageDialog(null,"server is attempting to get I/O streams");
        output = new ObjectOutputStream(connection.getOutputStream());
        output.flush();
        input = new ObjectInputStream(connection.getInputStream());
        //JOptionPane.showMessageDialog(null,"server has gotten I/O streams");
    }//end getStreams() 

    @Override
    public void run() {
        try {
            //JOptionPane.showMessageDialog(null, "client "+clientNo+" running");
            // while(true){
            waitForConnection();
            getStreams();
            processConnection();
            // }//end while
        } catch (IOException ex) {
            Logger.getLogger(ConnectedClients.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * processes all actions that take place after connection is instantiated
     *
     * @throws IOException
     */
    private void processConnection() throws IOException {
        String message = "";//= "Connection successful";
        ClientMessage clientMessage = null;
        // sendData(message);
        int[] sNumbers = new int[clients.length];
        int sNumberCounter = 0;
        int theSNumber = 0;
        setTextFieldEditable(true);
        ResultSet resultSet;
        do {
            try {
                clientMessage = (ClientMessage) input.readObject();
                if (clientMessage.getMessageType() == ClientMessage.MESSAGE_TYPE_SEND_MY_KEY_REQUEST) {
                    ServerMessage serverMessage = new ServerMessage("Server", clientMessage.getSender(), ServerMessage.SENDING_KEY_REQUEST, clientMessage.getMessage());// clientMessage.getMessage()                    
                    parentServer.sendMessageToOtherClients(this, serverMessage);
//                    }
                } else if (clientMessage.getMessageType() == ClientMessage.MESSAGE_TYPE_SEND_MESSAGE_REQUEST) {
                    String[] theMessage = clientMessage.getMessage();//empty message
                    ServerMessage serverMessage = new ServerMessage("Server", clientMessage.getSender(), ServerMessage.SEND_MESSAGE_TO_OTHER_CLIENTS_REQUEST, theMessage);
                    // this.sendData(serverMessage);//sends reply to client
                    parentServer.sendMessageToOtherClients(this, serverMessage);

                } else if (clientMessage.getMessageType() == ClientMessage.KEY_RECEIVED) {
                    String[] theMessage = clientMessage.getMessage();//empty message
                    ServerMessage serverMessage = new ServerMessage("Server", clientMessage.getSender(), ServerMessage.KEY_SENT_SUCCESSFULLY, theMessage);
                    // this.sendData(serverMessage);//sends reply to client
                    parentServer.sendMessageToOtherClients(this, serverMessage);
                }
            } catch (ClassNotFoundException classNotFoundException) {
                displayMessage("\nUnknown object type received");
            }
        } while (clientMessage.getMessageType() != ClientMessage.MESSAGE_TYPE_CONNECTION_TERMINATED);

    }//end processConnection()

    /**
     * validates user
     *
     * @param username
     * @param password
     * @return *
     *
     * private boolean isUserValid(String username, String password) { boolean
     * status = false; Database db = new
     * Database("src\\com\\maihanks\\Resources\\Database\\users.txt"); String[]
     * rows = db.getAllRows(); String[] rowEntity; String validUsername; String
     * validPassword; for (int a = 0; a < rows.length; a++) { rowEntity =
     * db.getSingleRowAttributes(rows[a]); validUsername = rowEntity[2];
     * validPassword = rowEntity[3]; if ((username.equals(validUsername)) &&
     * (password.equals(validPassword))) { status = true; break;//terminate loop
     * } else { status = false; } }//end for return status; }//end isUserValid()
     *
     */
    /**
     * generates the username for a new client
     *
     * @return * private String generateUsername(){ Database database = new
     * com.maihanks.FileDatabaseManager.Database("src\\com\\maihanks\\Resources\\Database\\users.txt");
     * int a = database.getNumberOfRows() + 1;
     * //JOptionPane.showMessageDialog(null, "a = "+a); String theUsername =
     * "user"+a; return theUsername; }
     */
    public void sendData(ServerMessage serverMessage) {
        try {
            output.writeObject(serverMessage);
            output.flush();
        } catch (IOException iOException) {
            displayArea.append("\nError writing object");
        }
    }//end sendData()

    public void disseminateMessage(String message) {
        for (int a = 0; a < clients.length; a++) {//iterates through all clients
            try {
                clients[a].sendData(message);//sends message                    
            } catch (Exception ex) {
            }//end catch
        }//end for loop
    }//end diseminateMessage

    public void disseminateMessage(ServerMessage serverMessage) {
        for (int a = 0; a < clients.length; a++) {//iterates through all clients
            try {
                clients[a].sendData(serverMessage);//sends message                    
            } catch (Exception ex) {
            }//end catch
        }//end for loop
    }//end diseminateMessage

    /**
     * sends message via this object
     *
     * @param message
     */
    public void sendData(String message, int clientNo) {
        try {
            //  output.writeObject("SERVER>>> " + message);
            // for (int a = 0; a < clients.length; a++) {
            //   if (a != clientNo) {
            // clients[a].getOutput().writeObject("SERVER>>> " + message);
            output.writeObject("SERVER>>>" + message);
            // }
            //}//end for
            output.flush();
        } catch (IOException iOException) {
            displayArea.append("\nError writing object");
        }
    }//end sendData()

    public void sendData(String message) {
        try {
            //  output.writeObject("SERVER>>> " + message);
            // for (int a = 0; a < clients.length; a++) {
            //   if (a != clientNo) {
            // clients[a].getOutput().writeObject("SERVER>>> " + message);
            output.writeObject(message);
            // }
            //}//end for
            output.flush();
        } catch (IOException iOException) {
            displayArea.append("\nError writing object");
        }
    }//end sendData()

    public void displayMessage(final String messageToDisplay) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                displayArea.append(messageToDisplay);
            }
        });
    }//end displayMessage()

    private void setTextFieldEditable(final boolean editable) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                enterField.setEditable(editable);
            }
        });

    }

    public void closeConnection() {
        displayMessage("\nTerminating Connection\n");
        setTextFieldEditable(false);

        try {
            output.close();
            input.close();
            connection.close();
        } catch (IOException iOException) {
            iOException.printStackTrace();
        }
    }//end closeConnection()
//static int defaultPrimeNumber = 7, generator = 3, privateNumber = 5, m, k;
//
//static int defaultPrimeNumber2 = 7, generator2 = 9, privateNumber2 = 10, m2,k2;
//
//    public static void main(String[] args) {        
//        m = (int) (Math.pow(generator, privateNumber) % defaultPrimeNumber);                        
//        m2 = (int) (Math.pow(generator2, privateNumber2) % defaultPrimeNumber2);             
//        k = (int) (Math.pow(m2, privateNumber) % defaultPrimeNumber);     
//                k2 = (int) (Math.pow(m, privateNumber2) % defaultPrimeNumber2);   
//        System.out.println(k+" , "+k2);
//    }
}
