/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.maihanks.kuw.general;

import java.io.Serializable;

/**
 *
 * @author MAIHANKS
 */
public class MessageType implements Serializable {
    
    public void setMessageType(int theMessageType){
        
    }
    /** a normal message*///NORMAL_MESSAGE,
    /**a request message that prompts validating user *///LOGIN_REQUEST,
/**a request message that prompts the server to register user *///REGISTER_USER;
}
