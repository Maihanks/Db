/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.maihanks.kuw.general;

/**
 * @author MAIHANKS
 * This interface defines the basic properties of any message, be it a server message or client message
 */
public interface Message {
    public String getSender();
    public String getReceiver();
    public String getMessageSendingDate();
    public String getMessageReceiveingDate();
    public String[] getMessage();
    public String getMessageSendingTime();
    
    public void setSender(String theSender);
}
