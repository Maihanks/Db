/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.maihanks.kuw.general;

import com.maihanks.kuw.client.Client;
import java.awt.Dimension;
import javax.swing.*;

/**
 *
 * @author MAIHANKS
 */
public class Sample {

    Client client;
    JFrame parentFrame = new JFrame("SAMPLE");
    JPanel parentPanel = new JPanel();
    
    public Sample(Client theClient) {
        client = theClient;
        setUpParentFrameComponents();
    }

    public void setUpParentFrameComponents() {
    parentFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    parentFrame.setBounds(100, 100, 700, 500);
    parentFrame.setLayout(null); 
    parentFrame.setResizable(false);
//    Dimension maximumSize = new java.awt.Dimension(800, 600);
//    parentFrame.setMaximumSize(maximumSize);
//        System.out.println(parentFrame.getMaximumSize().width);
    
    /*
     * NORMAL Indicates that no state bits are set.
ICONIFIED
MAXIMIZED_HORIZ
MAXIMIZED_VERT
MAXIMIZED_BOTH Concatenates MAXIMIZED_HORIZ and MAXIMIZED_VERT.
     */
    
    setUpParentPanelComponents();
      
    
    parentFrame.add(parentPanel);
    setUpEventHandlers();
    parentFrame.setVisible(true);
    
    }
    
    public void setUpParentPanelComponents(){
        
    parentPanel.setBounds(0,0,parentFrame.getWidth(),parentFrame.getHeight());
    
    }
    
    public void setUpEventHandlers(){
        
    
    }
//    public static void main(String[] args){
//    Sample Sample = new Sample(null);
//    }
}
